# SmartPlay TV — All-in-One (Single File)

> Arquivo único com *tudo* para iniciar o projeto: migrations SQL, policies RLS, Supabase Functions (Node), API (Express minimal), Admin (Next.js scaffold), App (Expo React Native scaffold), scripts de deploy e checklists.

---

## Como usar este arquivo

1. Copie as seções que precisa (cada arquivo sugerido está marcado com um cabeçalho e bloco de código com o nome do arquivo).
2. Crie um monorepo conforme a estrutura sugerida.
3. Rode `supabase start` localmente para testar as migrations.
4. Siga instruções nas seções *Deploy*.

---

## Estrutura do repositório (sugerida)

```
smartplay-monorepo/
  apps/
    client-app/        # Expo (React Native)
    admin-panel/       # Next.js + Tailwind
    api/               # Node/Express (optional) ou Supabase Functions
  infra/
    migrations/        # .sql files
  docs/
    README.md
```

---

# 1. Migrations SQL (Supabase/Postgres)

-- arquivo: infra/migrations/001_init.sql
```sql
-- 001_init.sql

-- profiles
create table if not exists profiles(
  id uuid primary key references auth.users(id),
  full_name text,
  role text default 'client',
  expires_at timestamptz,
  max_devices int default 2,
  created_at timestamptz default now()
);

-- devices
create table if not exists devices(
  id bigint generated always as identity primary key,
  user_id uuid references auth.users(id),
  device_id text not null,
  device_info jsonb,
  last_seen timestamptz default now(),
  created_at timestamptz default now()
);

-- online_users
create table if not exists online_users(
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id),
  device_id text,
  channel_id text,
  started_at timestamptz default now(),
  last_seen timestamptz default now()
);

-- watch_logs
create table if not exists watch_logs(
  id bigint generated always as identity primary key,
  user_id uuid references auth.users(id),
  channel_id text,
  started_at timestamptz default now(),
  ended_at timestamptz,
  device_id text
);

-- channels
create table if not exists channels(
  id bigint generated always as identity primary key,
  slug text unique,
  title text,
  description text,
  hls_url text,
  p2p_meta jsonb,
  created_at timestamptz default now()
);

-- indexes
create index if not exists idx_online_users_user on online_users(user_id);
create index if not exists idx_devices_user on devices(user_id);
```

---

# 2. RLS Policies (exemplos)

-- arquivo: infra/migrations/002_rls.sql
```sql
-- enable row level security on profiles and devices
alter table profiles enable row level security;
alter table devices enable row level security;
alter table online_users enable row level security;

-- profiles: owner can select/update, admins (role='admin') can select
create policy "profiles_select_own" on profiles for select using (auth.uid() = id);
create policy "profiles_update_own" on profiles for update using (auth.uid() = id);

-- devices: authenticated users can insert but only for themselves
create policy "devices_insert_auth" on devices for insert with check (auth.uid() = user_id);
create policy "devices_select_owner" on devices for select using (auth.uid() = user_id);

-- online_users: allow insert via service_role or edge functions (restricted)
-- for simplicity, allow insert if auth.uid() = user_id (client will own its own session rows)
create policy "online_users_insert_owner" on online_users for insert with check (auth.uid() = user_id);
create policy "online_users_select_own" on online_users for select using (auth.uid() = user_id);

-- watch_logs: allow insert for authenticated
create policy "watchlogs_insert" on watch_logs for insert with check (auth.uid() = user_id);
```

---

# 3. Supabase Edge Function: session handlers

> arquivo: apps/api/functions/session/index.js

```js
// session/index.js  (Supabase Edge Function)
import { serve } from 'std/server'
import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL = process.env.SUPABASE_URL
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)

serve(async (req) => {
  try {
    const url = new URL(req.url)
    if (req.method === 'POST' && url.pathname.endsWith('/start')) {
      const body = await req.json()
      const { user_id, channel_id, device_id } = body
      if (!user_id || !channel_id || !device_id) return new Response(JSON.stringify({ error: 'missing' }), { status: 400 })

      const { data, error } = await supabase
        .from('online_users')
        .insert({ user_id, channel_id, device_id, last_seen: new Date().toISOString() })
      if (error) return new Response(JSON.stringify({ error }), { status: 500 })
      return new Response(JSON.stringify({ data }), { status: 200 })
    }

    if (req.method === 'POST' && url.pathname.endsWith('/heartbeat')) {
      const body = await req.json()
      const { session_id } = body
      if (!session_id) return new Response(JSON.stringify({ error: 'missing session_id' }), { status: 400 })
      const { data, error } = await supabase
        .from('online_users')
        .update({ last_seen: new Date().toISOString() })
        .eq('id', session_id)
      if (error) return new Response(JSON.stringify({ error }), { status: 500 })
      return new Response(JSON.stringify({ data }), { status: 200 })
    }

    if (req.method === 'POST' && url.pathname.endsWith('/stop')) {
      const body = await req.json()
      const { session_id } = body
      if (!session_id) return new Response(JSON.stringify({ error: 'missing session_id' }), { status: 400 })
      const { data, error } = await supabase
        .from('online_users')
        .update({ last_seen: new Date().toISOString() })
        .eq('id', session_id)
      // optionally move to watch_logs
      return new Response(JSON.stringify({ data }), { status: 200 })
    }

    return new Response('Not Found', { status: 404 })
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 })
  }
})
```

---

# 4. Minimal API (Node/Express) — optional

> arquivo: apps/api/server/index.js

```js
// Minimal Express API for channels and device registration
const express = require('express')
const bodyParser = require('body-parser')
const { createClient } = require('@supabase/supabase-js')

const app = express()
app.use(bodyParser.json())

const SUPABASE_URL = process.env.SUPABASE_URL
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY)

app.get('/channels', async (req, res) => {
  const { data, error } = await supabase.from('channels').select('*')
  if (error) return res.status(500).json({ error })
  res.json({ data })
})

app.post('/devices/register', async (req, res) => {
  const { user_id, device_id, device_info } = req.body
  if (!user_id || !device_id) return res.status(400).json({ error: 'missing' })
  const { data, error } = await supabase.from('devices').insert({ user_id, device_id, device_info })
  if (error) return res.status(500).json({ error })
  res.json({ data })
})

app.listen(3333, () => console.log('API listening on 3333'))
```

---

# 5. Admin Panel (Next.js) — scaffold

> arquivo: apps/admin-panel/pages/index.js

```jsx
import { createClient } from '@supabase/supabase-js'
import { useEffect, useState } from 'react'

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY)

export default function Dashboard() {
  const [sessions, setSessions] = useState([])
  useEffect(() => {
    async function load() {
      const { data } = await supabase.from('online_users').select('*')
      setSessions(data)
    }
    load()

    const sub = supabase.channel('public:online_users').on('postgres_changes', { event: '*', schema: 'public', table: 'online_users' }, payload => {
      load()
    }).subscribe()

    return () => { sub.unsubscribe() }
  }, [])

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">SmartPlay Admin</h1>
      <h2 className="mt-4">Online Sessions</h2>
      <table className="min-w-full mt-2">
        <thead><tr><th>ID</th><th>User</th><th>Channel</th><th>Last seen</th></tr></thead>
        <tbody>
          {sessions?.map(s => (
            <tr key={s.id}><td>{s.id}</td><td>{s.user_id}</td><td>{s.channel_id}</td><td>{s.last_seen}</td></tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
```

> arquivo: apps/admin-panel/next.config.js
```js
/** @type {import('next').NextConfig} */
const nextConfig = { reactStrictMode: true }
module.exports = nextConfig
```

> arquivo: apps/admin-panel/package.json (scripts)
```json
{
  "name": "admin-panel",
  "scripts": {
    "dev": "next dev -p 3000",
    "build": "next build",
    "start": "next start -p 3000"
  }
}
```

---

# 6. Client App (Expo React Native) — scaffold

> arquivo: apps/client-app/App.js

```jsx
import React, { useEffect, useState } from 'react'
import { SafeAreaView, Text, Button, FlatList, TouchableOpacity } from 'react-native'
import Constants from 'expo-constants'
import * as Device from 'expo-device'
import { createClient } from '@supabase/supabase-js'
import 'react-native-get-random-values'
import { v4 as uuidv4 } from 'uuid'

const SUPABASE_URL = process.env.SUPABASE_URL
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)

export default function App() {
  const [channels, setChannels] = useState([])
  const [deviceId, setDeviceId] = useState(null)

  useEffect(() => {
    (async () => {
      let id = await AsyncStorage.getItem('device_id')
      if (!id) { id = uuidv4(); AsyncStorage.setItem('device_id', id) }
      setDeviceId(id)

      const { data } = await supabase.from('channels').select('*')
      setChannels(data || [])
    })()
  }, [])

  const startSession = async (channel) => {
    // assume user is authenticated and we have user_id
    const user = supabase.auth.user()
    await fetch(process.env.SUPABASE_FUNCTIONS_URL + '/session/start', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: user.id, channel_id: channel.slug, device_id: deviceId })
    })
    // open player (not implemented in this scaffold)
  }

  return (
    <SafeAreaView>
      <Text style={{ fontSize: 24, fontWeight: 'bold', margin: 12 }}>SmartPlay</Text>
      <FlatList
        data={channels}
        keyExtractor={i => String(i.id)}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => startSession(item)}>
            <Text style={{ padding: 12 }}>{item.title}</Text>
          </TouchableOpacity>
        )}
      />
    </SafeAreaView>
  )
}
```

> arquivo: apps/client-app/package.json (scripts)
```json
{
  "name": "client-app",
  "main": "node_modules/expo/AppEntry.js",
  "scripts": {
    "start": "expo start",
    "android": "expo start --android",
    "ios": "expo start --ios"
  }
}
```

---

# 7. Player (web HLS + P2P hint)

- Para Web: use `p2p-media-loader` com `hls.js`.
- Para RN: use `react-native-video` para HLS; P2P WebRTC em RN é complexo, recomenda usar SFU ou fallback HLS.

Exemplo (web):
```js
import Hls from 'hls.js'
import { P2PLoader } from 'p2p-media-loader-hlsjs'

const engine = new P2PLoader.Engine()
const loader = new P2PLoader(engine)
const hls = new Hls({ loader })
hls.loadSource('https://.../playlist.m3u8')
```

---

# 8. Signed HLS URLs (exemplo simples)

Gere URLs assinadas no servidor (Functions) com TTL curto:

```js
import crypto from 'crypto'
function signUrl(path, secret, ttlSeconds=60) {
  const expires = Math.floor(Date.now()/1000) + ttlSeconds
  const signature = crypto.createHmac('sha256', secret).update(`${path}:${expires}`).digest('hex')
  return `${path}?expires=${expires}&sig=${signature}`
}
```

---

# 9. Dockerfile (api) e docker-compose exemplo

> arquivo: docker-compose.yml

```yaml
version: '3.8'
services:
  supabase:
    image: supabase/postgres:15
    ports: [5432:5432]
  api:
    build: ./apps/api
    ports: [3333:3333]
```

---

# 10. Checklist MVP (repetido para ter tudo em um lugar)

- [ ] Migrations aplicadas no Supabase
- [ ] Policies RLS configuradas
- [ ] Supabase Edge Function `session` deployada
- [ ] Admin panel Next.js dev funcionando
- [ ] Expo app conectando e listando canais
- [ ] Player HLS integrado
- [ ] Heartbeat de sessão implementado

---

# 11. Scripts úteis

```bash
# rodar supabase local
supabase start
# aplicar migrations
supabase db reset # (cuidado com dados)
psql postgres://... -f infra/migrations/001_init.sql
# deploy functions
supabase functions deploy session
# rodar admin
cd apps/admin-panel && npm run dev
# rodar client
cd apps/client-app && npm start
```

---

# 12. Próximos passos sugeridos (prioridade)

1. Rodar migrations e garantir RLS está correta.
2. Criar 1 canal de teste na tabela `channels` com uma URL HLS pública.
3. Rodar o admin e conferir `online_users` vazio.
4. Rodar client, abrir canal e ver se session/start cria uma linha em `online_users`.

---

# 13. Licença

MIT

---

*Fim do arquivo único.*
